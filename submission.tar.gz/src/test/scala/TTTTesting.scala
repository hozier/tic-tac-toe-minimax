import cmpsci220.hw.tictactoe._
import scala.util.control.Breaks._

import Solution._

class TicTesting extends org.scalatest.FunSuite{

  // test("Does my rest work? (Parameterized by Int type) "){

  //  val x = fromList(List("Hey", "there", "Delilah", "what's", "it", "like", "in", "New", "York", "City"))
  //  val xx = fromList(List(7, 1, 8, 7, 9, 7, 8, 0, 1477, 20))
  //  val getMeRest = rest(xx) match {
  //    case Some(z) => toList(z)
  //    case None => Empty()
  //  }

  //  println("getting me rest " + getMeRest)
  // }


test("A1) Expected Winner: Some(X)"){
  val emptyBoard = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, Some(O)).set(0, 2, Some(X)).
  set(1, 0, Some(O)).set(1, 1, Some(X)).set(1, 2, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X)).set(2, 2, Some(X))
  val stewie = Solution.createGame(X, emptyBoard): Game //new Game(turn, board) 
  assert(stewie.getWinner == Some(X))

}
test("A2) Can my nxn board (3x3) detect a finished game\n\t\tif X has just won on the diagonal? "){ 
  val emptyBoard = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, Some(O)).set(0, 2, Some(X)).
  set(1, 0, Some(O)).set(1, 1, Some(X)).set(1, 2, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X)).set(2, 2, Some(X))
  val stewie = Solution.createGame(X, emptyBoard): Game //new Game(turn, board) 
  for(s<-emptyBoard.cols) { for(t<-s){printf(s"$t\t")   } ; println() } // . cols converts matrix into a list of list :)
  /*  attains access to inner list's components and prints each X/O component (some/none) out */ 


  println("1) isFinished is "+ stewie.isFinished)
  printf(s"getWinner is %s\n\n", stewie.getWinner.toString)
  assert(stewie.isFinished == true)

}

test("B1) Expected Winner: None"){
  val board1 = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, Some(O)).set(0, 2, Some(X)).
  set(1, 0, Some(O)).set(1, 1, Some(X)).set(1, 2, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X))
  val stewie = Solution.createGame(X, board1): Game //new Game(turn, board) 
  assert(stewie.getWinner == None)

}
test("B2) Given no player has won yet, can isFinished correctly \n\t\treturn false if there are still None elements in the matrix? "){
  val board1 = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, Some(O)).set(0, 2, Some(X)).
  set(1, 0, Some(O)).set(1, 1, Some(X)).set(1, 2, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X))
  val stewie = Solution.createGame(X, board1): Game //new Game(turn, board) 
  for(s<-board1.rows) { for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get) } else {printf(s"$t\t")} }; println() } 
  println("2) isFinished is "+ stewie.isFinished)
  printf(s"getWinner is %s\n\n", stewie.getWinner.toString)
  assert(stewie.isFinished == false)

}
test("C1) Expected Winner: None"){
  val board2 = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, Some(O)).set(0, 2, Some(X)).
  set(1, 0, Some(O)).set(1, 1, Some(X)).set(1, 2, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X)).set(2, 2, Some(O))
  val stewie = Solution.createGame(X, board2): Game //new Game(turn, board) 
  assert(stewie.getWinner == None)

}
test("C2) If ALL the elements in the matrix are of Option \n\t\ttype Some AND there is no winner, can we return None to represent \n\t\ta DRAW on a finished game? "){
  val board2 = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, Some(O)).set(0, 2, Some(X)).
  set(1, 0, Some(O)).set(1, 1, Some(X)).set(1, 2, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X)).set(2, 2, Some(O))
  val stewie = Solution.createGame(X, board2): Game //new Game(turn, board) 
  for(s<-board2.rows) { for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get) } else {printf(s"$t\t")} }; println() } 
  println("3) isFinished is "+ stewie.isFinished)
  printf(s"getWinner is %s\n\n", stewie.getWinner.toString)
  assert(stewie.isFinished == true)

}

test("D1) Expected Winner: Some(X)"){
  val board3 = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, Some(X)).set(0, 2, Some(X)).
  set(1, 0, Some(O)).set(1, 1, Some(X)).set(1, 2, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X))
  val stewie = Solution.createGame(X, board3): Game //new Game(turn, board) 
  assert(stewie.getWinner == Some(X))

}
test("D2) If X wins, can we correctly detect and return \n\t\tthat the game isFinished? "){
  val board3 = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, Some(X)).set(0, 2, Some(X)).
  set(1, 0, Some(O)).set(1, 1, Some(X)).set(1, 2, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X))
  val stewie = Solution.createGame(X, board3): Game //new Game(turn, board) 
  for(s<-board3.rows) { for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get) } else {printf(s"$t\t")} }; println() } 
  println("4) isFinished is "+ stewie.isFinished)
  printf(s"getWinner is %s\n\n", stewie.getWinner.toString)
  assert(stewie.isFinished == true)

}

test("E1) Scalability: Expected Winner: Some(X) of 4x4 matrix"){
val board4 = Matrix[Option[Player]](4, None).
  set(0, 0, Some(X)).set(0, 1, Some(X)).set(0, 2, Some(X)).set(0, 3, Some(O)).
  set(1, 0, Some(O)).set(1, 1, Some(O)).set(1, 3, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X)).set(2, 2, Some(O)).set(2, 3, Some(O)).
  set(3, 0, Some(O)).set(3, 1, Some(X)).set(3, 2, Some(O)).set(3, 3, Some(O))
  val stewie = new Game(X, board4) //new Game(turn, board) 
  assert(stewie.getWinner == Some(O))
}

test("E2) Scalability: Can we successfully perform isFinished on 4x4\n\t\t matrix, given X has won"){
val board4 = Matrix[Option[Player]](4, None).
  set(0, 0, Some(X)).set(0, 1, Some(X)).set(0, 2, Some(X)).set(0, 3, Some(O)).
  set(1, 0, Some(O)).set(1, 1, Some(O)).set(1, 3, Some(O)).
  set(2, 0, Some(O)).set(2, 1, Some(X)).set(2, 2, Some(O)).set(2, 3, Some(O)).
  set(3, 0, Some(O)).set(3, 1, Some(X)).set(3, 2, Some(O)).set(3, 3, Some(O))
  val stewie = new Game(X, board4) //new Game(turn, board) 
  for(s<-board4.rows) { for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get) } else {printf(s"$t\t")} }; println() } 
  println("4A) isFinished is "+ stewie.isFinished)
  printf(s"getWinner is %s\n\n", stewie.getWinner.toString)
  assert(stewie.isFinished == true)
}

test("F1) Scalability: Expected Winner: Some(X) of 9x9 matrix"){
  var board5 = Matrix[Option[Player]](9, None) //populate with for block
  for(k  <- 0 to board5.rows.head.length-1) {
    board5  = board5.set(7, k, Some(X)) 
    if( k == board5.rows.head.length-1) board5  = board5.set(7, 0, None)   
  } 
  for(i  <- 0 to board5.cols.length-1) { board5 = (board5.set(i, ((board5.cols.length-1) - i ),  Some(X) )) } // set the anti diagonal 
  val stewie = new Game(X, board5) //new Game(turn, board) 
  assert(stewie.getWinner == Some(X))
}

test("F2) Scalability: Can we successfully perform isFinished on 9x9\n\t\t matrix, given X has won (on the antidiagonal)? "){
  var board5 = Matrix[Option[Player]](9, None) //populate with for block
  for(k  <- 0 to board5.rows.head.length-1) {
    board5  = board5.set(7, k, Some(X)) 
    if( k == board5.rows.head.length-1) board5  = board5.set(7, 0, None)   
  } 
  for(i  <- 0 to board5.cols.length-1) { board5 = (board5.set(i, ((board5.cols.length-1) - i ),  Some(X) )) } // set the anti diagonal 
  // for(i  <- 0 to board5.cols.length-1) { board5 = (board5.set(i,   i ,  Some(X) )) } // set the diagonal 
  val stewie = new Game(X, board5) //new Game(turn, board) 
  for(s<-board5.rows) { for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get) } else {printf(s"$t\t")} }; println() } 
  println("5) isFinished is "+ stewie.isFinished) 
  printf(s"getWinner is %s\n\n", stewie.getWinner.toString)
  assert(stewie.isFinished == true)
}

test("G1) Scalability: Expected Winner: Some(X) of 5x5 matrix"){
  var board6 = Matrix[Option[Player]](5, None) //populate with for block
  for(k  <- 0 to board6.rows.head.length-1) {
    if(k % 2 == 0 ) { board6  = board6.set(4, k, Some(O)) } else board6  = board6.set(4, k, Some(X))
    if(k % 2 == 1 ) { board6  = board6.set(k, 1, Some(O)) } else board6  = board6.set(k, 1, Some(X))
    if(k % 2 == 0 ) { board6  = board6.set(2, k, Some(X)) } else board6  = board6.set(4, k, Some(O))

  } 

  board6 = board6.set(2, 3, Some(X))
  val stewie = new Game(X, board6) //new Game(turn, board) 
  assert(stewie.getWinner == Some(X))
}

test("G2) Scalability: Can we successfully perform isFinished on 5x5\n\t\t matrix, given X has won"){
  var board6 = Matrix[Option[Player]](5, None) //populate with for block
  for(k  <- 0 to board6.rows.head.length-1) {
    if(k % 2 == 0 ) { board6  = board6.set(4, k, Some(O)) } else board6  = board6.set(4, k, Some(X))
    if(k % 2 == 1 ) { board6  = board6.set(k, 1, Some(O)) } else board6  = board6.set(k, 1, Some(X))
    if(k % 2 == 0 ) { board6  = board6.set(2, k, Some(X)) } else board6  = board6.set(4, k, Some(O))

  } 

  board6 = board6.set(2, 3, Some(X))
  val stewie = new Game(X, board6) //new Game(turn, board) 
  for(s<-board6.rows) { for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get) } else {printf(s"$t\t")} }; println() } 
  println("9) isFinished is "+ stewie.isFinished) 
  printf(s"getWinner is %s\n\n", stewie.getWinner.toString)
  assert(stewie.isFinished == true)
}

test("1) Autogenerate an unfinished board. Winner? Expected: None"){
  var board = Matrix[Option[Player]](3, None)
  for(i <- 0 to board.rows.length-1){ //auto populate
      for(j <- 0 to board.rows.head.length-1){ if(j!=(board.rows.head.length-1)/4) { if(i%2 == 0){if(j % 2 == 0) board = board.set(i, j, Some(X)) else board = board.set(i, j, Some(O)) } else if(j % 2 == 0) board = board.set(i, j, Some(O)) else board = board.set(i, j, Some(X)) }}
  }

  val stewie = Solution.createGame(O, board): Game //new Game(turn, board) 
    for(s<-board.rows){ for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get)} else printf(s"$t\t") }; println() }; println() // print statements

  assert(stewie.getWinner == None)
}

test("2) Autogenerate an unfinished board. Expected: false"){
  var board = Matrix[Option[Player]](3, None)
  for(i <- 0 to board.rows.length-1){ //auto populate an unfinished scalable board
      for(j <- 0 to board.rows.head.length-1){ if(j!=(board.rows.head.length-1)/4) { if(i%2 == 0){if(j % 2 == 0) board = board.set(i, j, Some(X)) else board = board.set(i, j, Some(O)) } else if(j % 2 == 0) board = board.set(i, j, Some(O)) else board = board.set(i, j, Some(X))}}
  }
  val stewie = Solution.createGame(O, board): Game //new Game(turn, board) 
  assert(stewie.isFinished == false)
}

test("3) Autogenerate a finished board. Expected: true"){
  var board = Matrix[Option[Player]](3, None)
  for(i <- 0 to board.rows.length-1){ //auto populate a finished, scalable board
      for(j <- 0 to board.rows.head.length-1){  { if(i%2 == 0){if(j % 2 == 0) board = board.set(j,i, Some(X)) else board = board.set(i, i, Some(O)) } else if(j % 2 == 0) board = board.set(j, i, Some(O)) else board = board.set(j, i, Some(X)) }}
  }

  val stewie = new Game(O, board)
  for(s<-board.rows){ for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get)} else printf(s"$t\t") }; println() }; println() 
  assert(stewie.isFinished == true)
}

test("4) Autogenerate a board where X wins. Expected: Some(X)"){
  var board = Matrix[Option[Player]](3, None)
  for(i <- 0 to board.rows.length-1){ //auto populate a finished, scalable board
      for(j <- 0 to board.rows.head.length-1){  { if(i%2 == 0){if(j % 2 == 0) board = board.set(j,i, Some(X)) else board = board.set(i, i, Some(O)) } else if(j % 2 == 0) board = board.set(j, i, Some(O)) else board = board.set(j, i, Some(X)) }}
  }
  val stewie = new Game(O, board)
  assert(stewie.getWinner == Some(X))
}

test("5) Test nextBoards. Create a List of all Nones and check it \n\t\tagainst the list of all available next moves in List[Game].\n\t\tThe total # of Nones should equal the total number of all \n\t\tavailable next moves made (by next moves made I mean \n\t\tthat nextBoards has already been called and we're iterating \n\t\tthrough each Game element in list to make sure all \n\t\tnext available moves have actually been accounted for.)"){
  var i:Int = 0 
  var arrNones:List[(Int, Int)] = List[(Int, Int)] ()
  var board = Matrix[Option[Player]](3, None)
  for(i <- 0 to board.rows.length-1){ //auto populate an unfinished scalable board
      for(j <- 0 to board.rows.head.length-1){ if(j!=(board.rows.head.length-1)/4) { if(i%2 == 0){if(j % 2 == 0) board = board.set(i, j, Some(X)) else board = board.set(i, j, Some(O)) } else if(j % 2 == 0) board = board.set(i, j, Some(O)) else board = board.set(i, j, Some(X))}}
  }
  val stewie = Solution.createGame(O, board): Game //new Game(turn, board) 
  for(s<-board.cols){ for(j<-0 to s.length-1){ if( board.get(i, j) == None){ arrNones = arrNones:+(i,j)  }  }; i+=1 }; i=0   /**Creates a List of tuples of the ith, jth position of all the Nones in the board matrix.**/
  val stuart = stewie.nextBoards

  var some_count = 0 // some_count == the total amount of available moves MADE and recorded into the Game array; if some_count is equal to the length of array of Nones, that means that all possible moves have been detected and made into Game objects AND are all members of the List of Games.
  val iter = stuart.iterator 
  while(iter.hasNext){
    if(detect(iter.next)){printf("This element in Game[%s] at board.get(i,j) was None, now it is marked as a next available move. \n", some_count); some_count+=1}  
  }


  def detect(game: Game):Boolean = { // check the array of Nones which hold the available spots on the board for a next move against the array of Games which contain at each element a possible moved play. If all array index of all the Nones are present in the new boards, then we have covered all available moves.
  var i:Int = 0 
  var found = false
  var nextPlayer:Player = game.turn
  if(game.turn == O) nextPlayer = X else nextPlayer = O

  
  for(s<-game.board.rows){
    for( j <- 0 to game.board.dim - 1) {
      for(q<-arrNones) { if( game.board.get(q._1, q._2) == Some(nextPlayer)) {found = true; return found }}  }; i+=1 
  }
  found
 }

  assert(arrNones.length == some_count)
}

test("testing minimax"){
  var board = Matrix[Option[Player]](3, None)
  for(i <- 0 to board.rows.length-1){ //auto populate
      for(j <- 0 to board.rows.head.length-1){ if(j!=(board.rows.head.length-1)/4) { if(i%2 == 0){if(j % 2 == 0) board = board.set(i, j, Some(X)) else board = board.set(i, j, Some(O)) } else if(j % 2 == 0) board = board.set(i, j, Some(O)) else board = board.set(i, j, Some(X)) }}
  }
  val ttt = Matrix[Option[Player]](3, None).
  set(0, 0, Some(X)).set(0, 1, None).set(0, 2, Some(X)).
  set(1, 0, None).set(1, 1, Some(X)).set(1, 2, None).
  set(2, 0, None).set(2, 1, None).set(2, 2, None)

  val stewie = Solution.createGame(X, ttt): Game //new Game(turn, board) 
    for(s<-board.rows){ for(t<-s){ if(!t.isEmpty) { printf("%s\t", t.get)} else printf(s"$t\t") }; println() }; println() // print statements


    println(minimax(stewie))

  // assert(stewie.getWinner == None)
}


} //end 